const express = require('express');
const router = express.Router();
const crudControler = require('./crud.controler');

const Man = require('../models/man.model');

router.get("", crudControler(Man).getAll);

router.post("", crudControler(Man).post);
router.delete("/:id",crudControler(Man).deleteOne);
router.patch("/:id",crudControler(Man).update);
router.get("/:id", crudControler(Man).getOne);
//router.get("/:gender", crudControler(Man).getquery);

module.exports = router;