const express = require('express');
const router = express.Router();
const crudControler = require('./crud.controler');

const Women = require('../models/women.model');

router.get("", crudControler(Women).getAll);

router.post("", crudControler(Women).post);
router.delete("/:id",crudControler(Women).deleteOne);
router.patch("/:id",crudControler(Women).update);
router.get("/:id", crudControler(Women).getOne);
//router.get("/:gender", crudControler(Man).getquery);

module.exports = router;