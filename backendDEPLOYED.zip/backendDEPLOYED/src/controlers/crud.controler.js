

const getAll = (model)=> async (req,res)=>{
    try{
        const page = req.query.page || 1;
        const size = req.query.size || 1;
       // const query = {gender: "Female"};

        const item = await model.find()
        .lean()
        .exec();
        //const totalPages = Math.ceil((await model.find().countDocuments())/size);

        return res.send(item);
    }
    catch(err){
        return res.status(500).send(err.message);
    }
}

const getOne = (model) => async (req,res)=>{
    try{
         console.log(req.params.id);
        const item = await model.findById(req.params.id).lean().exec();
        return  res.status(200).send(item);
    }
    catch(err){
        return res.status(500).send(err.message);
    }
}

const getquery = (model) => async (req,res)=>{
    try{
        console.log(req.params.gender);
        const page = req.query.page || 1;
        const size = req.query.size || 1;

        const query = {gender: req.params.gender};
        const item = await model.find(query)   
        .skip((page-1)*size)
        .limit(size)
        .lean()
        .exec();
        const totalPages = Math.ceil((await model.find(query).countDocuments())/size);

        return res.send({item, totalPages});
    }
    catch(err){
        return res.status(502).send({message: err.message});
    }
};

const post = (model)=> async (req,res)=>{
    try{
        const item = await model.create(req.body);
        return res.status(201).send(item);
    }
    catch(err){
        return res.status(500).send(err.message);
    }
}

const update = (model)=> async (req, res)=>{
    try{
        const item = await model.findByIdAndUpdate(req.params.id, req.body, {
            new: true
        }).lean().exec();
        return res.status(201).send(item);
    }
    catch(err){
        return res.status(500).send(err.message);
    }
}

const deleteOne = (model)=> async (req,res)=>{
    try{
        //console.log(req.params.id);
        const item = await model.findByIdAndDelete(req.params.id).lean().exec();
        return  res.status(200).send(item);
    }
    catch{
        return res.status(500).send(err.message);
    }
}

module.exports = (model) => {
    return {
        post: post(model),
        getAll: getAll(model),
        getOne: getOne(model),
        update: update(model),
        deleteOne: deleteOne(model),
        getquery: getquery(model)
    }
}