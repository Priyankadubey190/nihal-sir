const Userdata = require('../models/auth.model');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const register = async  (req, res) => {
 const {name,mob_no,email,password,userType} = req.body;
    let existingUser = new Userdata();
    try{
        existingUser = await Userdata.findOne({email: email});
    }catch(err){
        console.log(err);
    }
    if(existingUser){
        return res.status(400)
        .json({message: "User already exists! Login Insted"});
    }
    const hashedPassword = bcrypt.hashSync(password);
    const userdata = new Userdata({
        name,
        mob_no,email,
        password:hashedPassword,userType
    });
    try{
        await userdata.save();
    } catch(err){
        console.log(err);
    }   
    return res.status(201).json({message: userdata});
};

const login = async (req, res) => {
    const {email,password} = req.body;

    let existingUser
    try{
        existingUser = await Userdata.findOne({email: email});
    }catch(err){
        return new Error(err);
    }
    if(!existingUser){
        return res.status(400).json({message: "User not found. Signup Please"});
    }
    const isPasswordCorrect = bcrypt.compareSync(password, existingUser.password);
    if(!isPasswordCorrect){
        return res.status(400).json({message: "Invalid Email / Password"});
    }
    const token = jwt.sign({id: existingUser._id},process.env.JWT_SECRET_KEY, {
        expiresIn: "1hr",
    });
    return res
    .status(200)
    .json({message: "Successfully Logged In", userdata: existingUser,token});

}
// 
// router.post("/signup",  (req, res) => {

//     bcrypt.hash(req.body.password, 10, (err, hash) => {
//         if (err) {
//             return res.status(500).json({ error: err })
//         }
//         else {
//             const userdata = new Signup({
//                 name: req.body.name,
//                 mob_no: req.body.mob_no,
//                 email: req.body.email,
//                 password: hash,
//                 userType: req.body.userType
//             })
//             userdata.save().then(result => {
//                 res.status(200).json({ new_signup: result })
//             }).catch(err => {
//                 res.status(500).json({ error: err })
//             })
//         }
//     })
// })

// router.post("/login", (req, res) => {
//     Signup.find({ name: req.body.name }).exec().then(user => {
//         if (user.length < 1) {
//             return res.status(401).json({ msg: 'user not exist' })
//         }
//         bcrypt.compare(req.body.password.userdata[0].password, (err, result) => {
//             if (!result) {
//                 return res.status(401).json({ msg: 'password maching failed' })
//             }
//             if (result) {
//                 const token = jwt.sign({
//                     name: userdata[0].name,
//                     mob_no: userdata[0].mob_no,
//                     email: userdata[0].email,
//                     userType: userdata[0].userType
//                 },

//                     "this is dummy text",
//                     {
//                         expiresIn: "24h"
//                     }
//                 );
//                 res.status(200).json({
//                     name: userdata[0].name,
//                     mob_no: userdata[0].mob_no,
//                     email: userdata[0].email,
//                     userType: userdata[0].userType,
//                     token: token
//                 })
//             }
//         })
//     })
// })
module.exports = {register, login};