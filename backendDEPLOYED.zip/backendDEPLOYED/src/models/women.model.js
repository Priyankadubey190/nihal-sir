const mongoose = require('mongoose');

const womenSchema = new mongoose.Schema({
    id: {type: String, require: true},
    image: {type: String, require: true},
    color: {type: String, require: true},
    price: {type: String, require: true},
    review: {type: String, require: true}
},
{
    varsion: false,
    timestamps: true
}
);
//------------------model-------------------
module.exports = mongoose.model("women", womenSchema);