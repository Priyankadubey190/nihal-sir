const mongoose = require('mongoose');


const signuoSchema = new mongoose.Schema({
  name : {type: String, required: true},
  mob_no: {type: Number, required: true},
  email: {type: String, required: true}, 
  password: {type: String, required: true},
  userType: {type: String, required: true}
})

module.exports = mongoose.model("userdata", signuoSchema);