const mongoose = require('mongoose');

const connect = ()=>{
    return mongoose.connect("mongodb+srv://priyanka:priyanka123@cluster0.acpsd.mongodb.net/lystdb?retryWrites=true&w=majority");
};

module.exports = connect;