
const express = require('express');
const cors = require('cors');
const connect = require("./config/db");
const router = express.Router();
const app = express();
app.use(express.json());
app.use(cors());

const manController = require('./controlers/man.controler');
const womenController = require('./controlers/women.controler');
const {register,login} = require('./controlers/auth.controller');
app.use("/man", manController);
app.use("/women", womenController);
app.use("/signup", register);
app.use("/login", login);
  

app.listen(process.env.PORT || 4111, async function () {
    try{
        await connect();
        console.log("listening on port 4111");
        
    }
    catch(e){
        console.log(e.message);
    }
});