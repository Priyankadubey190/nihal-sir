import React from 'react'

export const Button: React.FC<
    React.ButtonHTMLAttributes<HTMLButtonElement> 
> = (props) => {
    const { children, className, ...otherProps } = props
    return (
        <button
            {...otherProps}
            className={`bg-[#E01C23] transition-all px-6 md:px-9 py-3 hover:bg-red-700 text-white shadow-lg font-black  ${className}`}
        >
            {children}
        </button>
    )
}
