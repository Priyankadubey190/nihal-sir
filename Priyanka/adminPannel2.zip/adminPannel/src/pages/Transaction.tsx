import React from "react";

const Transaction = () => {
  return (
    <div>
      <div>Transaction</div>
    </div>
  );
};

export default Transaction;
