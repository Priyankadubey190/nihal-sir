import React from "react";

export const Products = () => {
  return (
    <div>
      Products
      <div></div>
    </div>
  );
};

export default Products;
