import React from "react";

const Customers = () => {
  return (
    <div>
      <div>Customers</div>
    </div>
  );
};

export default Customers;
