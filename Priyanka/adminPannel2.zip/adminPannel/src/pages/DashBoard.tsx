import { Button, Loader } from "@/components";
import React from "react";

const DashBoard = () => {
  return (
    <div>
      dashBoard
      <Loader />
      <Button/>
      <div></div>
    </div>
  );
};

export default DashBoard;
